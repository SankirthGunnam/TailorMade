import { Cart } from "@/screens/cart";

const CartLayout = () => {
  return <Cart />;
};

export default CartLayout;
