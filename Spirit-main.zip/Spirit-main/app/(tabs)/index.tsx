import Home from "@/screens/home";
import { View } from "react-native";

const HomeRoute = () => {
  return (
    <View>
      <Home />
    </View>
  );
};

export default HomeRoute;
