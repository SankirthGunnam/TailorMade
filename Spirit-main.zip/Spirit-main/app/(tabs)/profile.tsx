import ProfileScreen from "@/screens/profile";
import { Text, View } from "react-native";

export default function Index() {
  return (
      <ProfileScreen />
  );
}
