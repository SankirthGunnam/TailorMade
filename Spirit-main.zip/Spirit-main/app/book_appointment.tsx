import React from "react";
import { View, Text, Button, TouchableOpacity } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Surface } from "react-native-paper";
import { Ionicons } from "@expo/vector-icons";

const BookAppointment = () => {
  const navigation = useNavigation();

  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <Surface elevation={4} style={{ borderRadius: 100 }}>
        <TouchableOpacity
          className="h-28 w-28 bg-gray-50 rounded-full flex items-center justify-center border border-gray-200"
          onPress={() => navigation.goBack()}
        >
          <Ionicons name="medkit" size={24} color="black" />
          <Text className="text-black">Go Back</Text>
        </TouchableOpacity>
      </Surface>
    </View>
  );
};

export default BookAppointment;
