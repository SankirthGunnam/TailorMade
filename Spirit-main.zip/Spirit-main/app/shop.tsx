// shop.js
import React, { useState } from 'react';
import { View, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { Searchbar, Card, Text } from 'react-native-paper';
import { useRouter } from 'expo-router';

const categories = [
  { id: '1', name: 'Pain Relief' },
  { id: '2', name: 'Cold & Flu' },
  { id: '3', name: 'Digestive Health' },
  { id: '4', name: 'First Aid' },
  { id: '5', name: 'Vitamins & Supplements' },
  // Add more categories as needed
];

export default function ShopPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const router = useRouter();

  const renderCategoryItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.categoryItem}
      onPress={() => router.push({
        pathname: '/item_category',
        params: { category: item.name }
      })}
    >
      <Card>
        <Card.Content>
          <Text style={styles.categoryText}>{item.name}</Text>
        </Card.Content>
      </Card>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Searchbar
        placeholder="Search medicines"
        onChangeText={setSearchQuery}
        value={searchQuery}
        style={styles.searchBar}
      />
      <FlatList
        data={categories}
        renderItem={renderCategoryItem}
        keyExtractor={item => item.id}
        numColumns={2}
        contentContainerStyle={styles.categoryList}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  searchBar: {
    marginBottom: 10,
  },
  categoryList: {
    paddingHorizontal: 5,
  },
  categoryItem: {
    flex: 1,
    margin: 5,
  },
  categoryText: {
    textAlign: 'center',
  },
});