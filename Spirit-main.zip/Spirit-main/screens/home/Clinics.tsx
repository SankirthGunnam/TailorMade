import { ScrollView, Text, View } from "react-native";
import { Surface } from "react-native-paper";

export const Clinics = () => {
  return (
    <View className="mt-4">
      <Text className="px-4 mb-4 text-xl">Clinics near you</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <View className="h-full w-4" />
        <ClinicCard />
        <ClinicCard />
        <ClinicCard />
        <ClinicCard />
      </ScrollView>
    </View>
  );
};

const ClinicCard = () => {
  return (
    <View className="mr-4 my-2">
      <Surface
        elevation={1}
        style={{ borderRadius: 8 }}
        className="overflow-hidden"
      >
        <View className="h-[150px] w-[200px] rounded-lg flex items-center justify-center bg-white">
          <Text>Clinic 1</Text>
        </View>
      </Surface>
    </View>
  );
};
